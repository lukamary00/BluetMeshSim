"""
Module contain an implementation of environment.

Environment - is an object, that describes world, with which should interact
existing elements.
"""
from simulation.environment.environment import Environment
