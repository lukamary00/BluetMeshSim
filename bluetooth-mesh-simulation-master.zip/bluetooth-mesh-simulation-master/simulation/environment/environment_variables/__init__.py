"""Module provides main environment variables."""
from .enivronment_variable import EnvironmentVariable
from .temperature import Temperature