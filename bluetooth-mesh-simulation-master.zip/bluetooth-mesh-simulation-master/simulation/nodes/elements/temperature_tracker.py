from simulation.nodes.elements import Element

class TemperatureTracker(Element):
    pass