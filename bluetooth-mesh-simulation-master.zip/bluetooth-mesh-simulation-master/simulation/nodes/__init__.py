"""Package contains all node types, that exists in simulation.

Node - is some object, that can communicate via network and
observe properties of environment.
"""
from simulation.nodes.node import Node