"""Module contain implementations of generic models."""
