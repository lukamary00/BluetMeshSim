"""Module contains implementation of tabs."""
from simulation.tabs.main_window import MainWindow
from simulation.tabs.screen_file_chooser import ScreenFileChooser
